(() => {
  'use strict';
  const story = document.querySelector('.city-story');
  if (!story) return;
  const canvas = document.querySelector('#city-canvas');
  const hero = document.querySelector('.city-hero');
  const chapters = [...document.querySelectorAll('.city-chapter')];
  const cue = document.querySelector('.city-scroll-cue');
  const progress = document.querySelector('.city-chapter-progress');
  const note = document.querySelector('.city-art-note');
  const marker = document.querySelector('.store-marker');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const mobile = matchMedia('(max-width:580px)');
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
  let renderer, scene, camera, path, lookPath, projected, animation, shopAccent, shopLight, paused = false;
  const coordinate = document.querySelector('.scene-coordinate');
  const rate = document.querySelector('[data-after-rate]');
  const delta = document.querySelector('[data-rate-delta]');
  const afterBar = document.querySelector('[data-after-bar]');
  const markerText = document.createTextNode('');
  marker.replaceChildren(Object.assign(document.createElement('span'), {}), markerText);
  let target = 0, current = 0, last = -1, dirty = true, lastTime = 0;
  const resources = [];
  function readScroll() {
    target = clamp(-story.getBoundingClientRect().top / Math.max(1, story.offsetHeight - innerHeight));
    dirty = true;
  }
  function setMotion() {
    document.body.classList.toggle('reduced-motion', reduce.matches);
    dirty = true;
    readScroll();
  }
  setMotion();
  reduce.addEventListener('change', setMotion);
  function fallback() {
    canvas.hidden = true;
    canvas.style.display = 'none';
    document.querySelector('.city-fallback').hidden = false;
    story.dataset.renderState = 'unavailable';
    document.body.classList.add('reduced-motion');
  }
  function createCity() {
    const T = window.THREE;
    if (!T) throw new Error('Three.js unavailable');
    renderer = new T.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'low-power' });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = T.PCFSoftShadowMap;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.13;
    scene = new T.Scene();
    scene.background = new T.Color('#f5f3ed');
    scene.fog = new T.Fog('#f5f3ed', 65, 135);
    camera = new T.PerspectiveCamera(39, 1, .1, 180);
    projected = new T.Vector3();
    const ambient = new T.HemisphereLight('#fff9e9', '#b3b8a4', 2.6);
    scene.add(ambient);
    const sun = new T.DirectionalLight('#fff1d5', 3.3);
    sun.position.set(-24, 42, 25);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -40, right: 40, top: 40, bottom: -40, near: .1, far: 130 });
    sun.shadow.normalBias = .035;
    sun.shadow.bias = -.0001;
    scene.add(sun);
    const unit = new T.BoxGeometry(1, 1, 1);
    const leafGeometry = new T.IcosahedronGeometry(1, 1);
    resources.push(unit, leafGeometry);
    const mat = color => { const m = new T.MeshStandardMaterial({ color, roughness: .88, metalness: .02 }); resources.push(m); return m; };
    const stone = ['#dfd9c9', '#d0d2c3', '#eee8d8', '#c8c3b4', '#dedfd3', '#bcbdae'].map(mat);
    const trim = mat('#f0ecdf'), glass = mat('#77867a'), trunk = mat('#8b8069');
    const foliage = ['#9ba88b', '#b1b99c', '#859579'].map(mat);
    const bronze = mat('#887057'), warm = mat('#dfcca3');
    function box(w, h, d, x, y, z, material, shadow = true) {
      const mesh = new T.Mesh(unit, material);
      mesh.scale.set(w, h, d); mesh.position.set(x, y, z);
      mesh.castShadow = shadow; mesh.receiveShadow = true; scene.add(mesh); return mesh;
    }
    box(105, .3, 105, 0, -.3, 0, mat('#e1e2d5'), false);
    box(5.6, .05, 93, 0, -.1, 0, mat('#c5c8bb'), false);
    [-1, 1].forEach(side => box(2.0, .18, 93, side * 3.8, -.04, 0, trim, false));
    for (let z = -39; z < 43; z += 7) box(.075, .02, 2.2, 0, -.055, z, trim, false);
    for (let i = 0; i < 7; i++) box(.43, .025, 1.65, -2.2 + i * .73, -.035, 7, trim, false);
    const windows = [];
    for (const side of [-1, 1]) {
      for (let col = 0; col < 2; col++) {
        for (let row = 0; row < 8; row++) {
          const z = -35 + row * 10.5, x = side * (7.1 + col * 9.0);
          if (side === -1 && col === 0 && (row === 2 || row === 3)) continue;
          const seed = row * 7 + col * 3 + (side + 1) * 4;
          const w = 4.6 + (seed % 3) * .45, h = 4 + (seed % 5) * 1.13, d = 6.4;
          box(w, h, d, x, h / 2, z, stone[seed % stone.length]);
          box(w + .18, .22, d + .18, x, h + .06, z, trim);
          box(w * .48, .55, d * .48, x, h + .42, z, stone[(seed + 2) % 6]);
          for (let floor = .9; floor < h - .7; floor += 1.7) {
            for (let n = 0; n < 3; n++) windows.push({ x: x - w * .3 + n * w * .3, y: floor, z: z + d / 2 + .015, w: .62, h: .9, d: .045 });
            for (let n = 0; n < 3; n++) windows.push({ x: x - side * (w / 2 + .015), y: floor, z: z - 1.9 + n * 1.9, w: .045, h: .9, d: .75 });
          }
          box(w * .78, 1.65, .07, x, .96, z + d / 2 + .02, glass, false);
          box(w + .15, .14, .68, x, 2.05, z + d / 2 + .24, stone[(seed + 1) % 6]);
        }
      }
    }
    const windowMesh = new T.InstancedMesh(unit, glass, windows.length);
    const transform = new T.Object3D();
    windows.forEach((w, i) => { transform.position.set(w.x, w.y, w.z); transform.scale.set(w.w, w.h, w.d); transform.updateMatrix(); windowMesh.setMatrixAt(i, transform.matrix); });
    windowMesh.instanceMatrix.needsUpdate = true; scene.add(windowMesh);
    // A modest Korean restaurant is the destination, rather than a floating 3D icon.
    const storeX = -7.1, storeZ = -14;
    shopAccent = mat('#887057'); shopLight = mat('#77867a');
    shopAccent.userData.destination = new T.Color('#335d3e');
    shopLight.userData.destination = new T.Color('#b5ac76');
    shopLight.emissive.set('#c4a568');
    box(4.8, 4.15, 6.4, storeX, 2.075, storeZ, mat('#e9ddc5'));
    box(5.0, .23, 6.6, storeX, 4.22, storeZ, shopAccent);
    box(4.35, 2.05, .1, storeX, 1.22, storeZ + 3.24, shopLight);
    box(.13, 2.2, .14, storeX, 1.18, storeZ + 3.34, shopAccent);
    box(.1, 2.2, .14, storeX - 1.5, 1.18, storeZ + 3.34, shopAccent);
    box(.1, 2.2, .14, storeX + 1.5, 1.18, storeZ + 3.34, shopAccent);
    // Timber seating, entrance paving, table and planting make this a real destination.
    const timber = mat('#a78a65'), terracotta = mat('#8e876b');
    box(4.9, .12, 2.2, storeX, .02, storeZ + 4.2, trim, false);
    box(1.6, .12, .56, storeX + 1.2, .55, storeZ + 4.05, timber);
    [-.6,.6].forEach(offset => box(.12, .5, .4, storeX + 1.2 + offset, .25, storeZ + 4.05, bronze));
    box(.75, .09, .75, storeX - 1.2, .79, storeZ + 4.1, timber);
    box(.12, .78, .12, storeX - 1.2, .39, storeZ + 4.1, bronze);
    [-2.5, 2.5].forEach(offset => {
      box(.5, .55, .5, storeX + offset, .28, storeZ + 3.8, terracotta);
      const shrub = new T.Mesh(leafGeometry, foliage[2]); shrub.position.set(storeX + offset, .9, storeZ + 3.8); shrub.scale.set(.37,.52,.37); scene.add(shrub);
    });
    for (let n = 0; n < 10; n++) box(.49, .07, 1.08, storeX - 2.25 + n * .5, 2.5, storeZ + 3.65, n % 2 ? trim : shopAccent);
    box(5.05, .08, 1.1, storeX, 2.57, storeZ + 3.65, shopAccent);
    box(4.45, .6, .17, storeX, 3.37, storeZ + 3.25, warm);
    const signCanvas = document.createElement('canvas'); signCanvas.width = 768; signCanvas.height = 128;
    const texture = new T.CanvasTexture(signCanvas); texture.colorSpace = T.SRGBColorSpace; resources.push(texture);
    const signMat = new T.MeshStandardMaterial({ map: texture, roughness: 1 }); resources.push(signMat);
    box(3.45, .55, .025, storeX, 3.37, storeZ + 3.35, signMat, false);
    function drawSign() { const c = signCanvas.getContext('2d'); c.fillStyle = '#dfcca3'; c.fillRect(0, 0, 768, 128); c.fillStyle = '#4b4e3c'; c.font = '500 62px Pretendard, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('망원밥상', 384, 69); texture.needsUpdate = true; dirty = true; }
    drawSign(); document.fonts.ready.then(drawSign);
    box(.6, .8, .6, storeX + 2.95, .4, storeZ + 3.8, bronze);
    box(.8, 1.1, .16, storeX + 2.95, 1.3, storeZ + 3.8, warm);
    for (const side of [-1, 1]) {
      for (let i = 0; i < 8; i++) {
        const x = side * 4.05, z = -34 + i * 10.5;
        box(.16, 1.9, .16, x, .95, z, trunk);
        const leaf = new T.Mesh(leafGeometry, foliage[i % 3]); leaf.position.set(x, 2.6, z); leaf.scale.set(.98, 1.27, 1.0); leaf.castShadow = true; scene.add(leaf);
        if (i % 2 === 0) { box(.075, 3.1, .075, side * 3.03, 1.55, z + 3, bronze); box(.32, .12, .35, side * 3.03, 3.12, z + 3, warm); }
      }
    }
    for (const [x, z] of [[1.6, 22], [-1.5, -24]]) {
      box(1.35, .65, 2.6, x, .47, z, mat('#9fa796')); box(1.2, .5, 1.4, x, 1.04, z - .15, trim);
    }
    const points = [[24, 29, 52], [14, 18, 29], [3.8, 7.4, 15], [1.4, 4.0, 4.5], [1.2, 3.3, -.8]];
    path = new T.CatmullRomCurve3(points.map(p => new T.Vector3(...p)), false, 'catmullrom', .32);
    lookPath = new T.CatmullRomCurve3([[0, 2, -9], [-3, 2, -11], [-4, 2.3, -12], [-3.3, 2.1, -12], [-3.7, 2.05, -12]].map(p => new T.Vector3(...p)), false, 'catmullrom', .3);
    function resize() { const w = innerWidth, h = innerHeight; renderer.setSize(w, h, false); camera.aspect = w / h; camera.fov = mobile.matches ? 53 : 39; camera.updateProjectionMatrix(); dirty = true; readScroll(); }
    resize(); addEventListener('resize', resize, { passive: true });
    canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); fallback(); paused = true; });
    story.dataset.buildings = '31';
  }
  try { createCity(); } catch (error) { console.warn('City preview uses a static fallback:', error.message); fallback(); }
  function update(p) {
    const reduced = document.body.classList.contains('reduced-motion');
    const heroOpacity = 1 - smooth(.035, .15, p);
    hero.style.opacity = heroOpacity;
    hero.style.transform = `translate3d(0,${-35 * (1 - heroOpacity)}px,0)`;
    hero.inert = !reduced && heroOpacity < .1;
    cue.style.opacity = 1 - smooth(.01, .10, p);
    const ranges = [[.12, .16, .345, .38], [.38, .415, .645, .68], [.68, .715, 1.02, 1.08]];
    chapters.forEach((chapter, i) => {
      const [a, b, c, d] = ranges[i], opacity = smooth(a, b, p) * (1 - smooth(c, d, p));
      chapter.style.opacity = opacity;
      chapter.style.transform = mobile.matches ? `translateY(${(1 - opacity) * 32}px)` : `translateY(calc(-50% + ${(1 - opacity) * 42}px))`;
      chapter.querySelectorAll('.headline-line>b').forEach((line, j) => {
        const enter = reduced ? 1 : smooth(a + j * .006, b + j * .006, p);
        const leave = reduced ? 0 : smooth(c, d, p);
        line.style.transform = `translateY(${(1 - enter) * 105 - leave * 55}%)`;
        line.style.opacity = enter * (1 - leave);
      });
      chapter.setAttribute('aria-hidden', !reduced && opacity < .1 ? 'true' : 'false');
    });
    const chapterIndex = p < .38 ? 1 : p < .68 ? 2 : 3;
    if (coordinate) {
      coordinate.style.opacity = smooth(.09, .15, p);
      coordinate.querySelector('b').textContent = ['01 — FIND THE GAP', '02 — CHANGE THE INFORMATION', '03 — MEASURE THE DIFFERENCE'][chapterIndex - 1];
    }
    const countProgress = reduced ? 1 : smooth(.72, .82, p);
    if (rate) rate.textContent = String(20 + Math.round(countProgress * 20));
    if (delta) delta.textContent = String(Math.round(countProgress * 20));
    if (afterBar) afterBar.style.width = `${40 + countProgress * 40}%`;
    markerText.textContent = p < .38 ? '우리 가게 · 진단 중' : p < .68 ? '우리 가게 · 정보 정비' : '우리 가게 · 전후 비교';
    progress.querySelector('.current').textContent = String(chapterIndex).padStart(2, '0');
    progress.querySelector('i').style.width = `${p * 100}%`;
    progress.style.opacity = note.style.opacity = smooth(.14, .2, p);
    story.dataset.progress = p.toFixed(3); story.dataset.chapter = String(chapterIndex);
    if (renderer && !paused) {
      const position = reduced ? .32 : p;
      const lift = reduced ? 1 : smooth(.405, .58, p);
      shopAccent.color.set('#887057').lerp(shopAccent.userData.destination, lift);
      shopLight.color.set('#77867a').lerp(shopLight.userData.destination, lift);
      shopLight.emissiveIntensity = lift * .2;
      camera.position.copy(path.getPoint(position));
      const aim = lookPath.getPoint(position);
      if (mobile.matches && !reduced) {
        const focus = smooth(.30, .65, p);
        aim.x += (-6.7 - aim.x) * focus;
        aim.y -= 2.5 * focus;
      }
      camera.lookAt(aim);
      canvas.style.transform = `translate3d(0,${(1 - smooth(.01, .17, p)) * innerHeight * .48}px,0)`;
      renderer.render(scene, camera);
      story.dataset.renderState = 'ready';
      projected.set(-7.1, 4.5, -10.8).project(camera);
      const x = (projected.x * .5 + .5) * innerWidth, y = (-projected.y * .5 + .5) * innerHeight;
      marker.style.transform = `translate3d(${x - 18}px,${y - 54}px,0)`;
      marker.style.opacity = !reduced && p > .22 && projected.z < 1 && x > 25 && x < innerWidth - 100 && y > 110 && y < innerHeight - 80 ? smooth(.22, .28, p) : 0;
    }
  }
  function tick(time) {
    animation = requestAnimationFrame(tick);
    if (paused || time - lastTime < 30) return;
    lastTime = time;
    current += (target - current) * .16;
    if (Math.abs(target - current) < .0001) current = target;
    if (dirty || Math.abs(current - last) > .00001) { update(current); last = current; dirty = false; }
  }
  document.querySelectorAll('a[href="#diagnose"],a[href="#optimize"],a[href="#impact"]').forEach(link => link.addEventListener('click', event => {
    if (!document.body.classList.contains('reduced-motion')) return;
    const index = { '#diagnose': 0, '#optimize': 1, '#impact': 2 }[link.getAttribute('href')];
    event.preventDefault();
    chapters[index].scrollIntoView({ behavior: 'auto', block: 'center' });
  }));
  addEventListener('scroll', readScroll, { passive: true });
  addEventListener('resize', readScroll, { passive: true });
  addEventListener('pagehide', event => { paused = true; cancelAnimationFrame(animation); if (!event.persisted && renderer) { resources.forEach(r => r.dispose()); renderer.dispose(); } });
  addEventListener('pageshow', event => { if (event.persisted) { paused = false; dirty = true; animation = requestAnimationFrame(tick); } });
  readScroll(); animation = requestAnimationFrame(tick);
})();
