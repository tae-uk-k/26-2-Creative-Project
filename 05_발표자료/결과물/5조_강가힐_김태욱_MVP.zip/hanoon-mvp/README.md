# 한눈(Hanoon) MVP

외국인 관광객이 ChatGPT·Gemini 같은 AI에게 장소를 물어볼 때, 소규모 가게가 추천 답변에 발견될 가능성을 높이도록 현재 노출 상태를 진단하고 온라인 정보를 정비한 뒤 전후 변화를 보여주는 시연용 MVP입니다.

## 구현 범위

- 서비스 소개 랜딩 페이지
- 가게 정보 입력 및 유효성 검사
- 더미데이터 기반 AI 노출 진단 보고서
- 영문 정보·관광객 조건·채널 일관성 개선안
- 영문 소개 문안 편집·복사·승인
- 공개 영문 소개 페이지 미리보기
- 동일 조건의 개선 전후 지표 비교
- 모바일·데스크톱 반응형 화면

실제 OpenAI·Gemini API, 지도·SNS 자동 수정, 결제, 회원가입, 결과 영구 저장은 포함하지 않습니다.

## 실행 방법

Windows PowerShell 기준:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

브라우저에서 `http://127.0.0.1:5000`에 접속합니다.

Windows에서는 `run.bat`을 실행해도 같은 과정을 자동으로 진행합니다.

## 테스트

```powershell
python -m pytest -q
```

## 프로젝트 구조

```text
hanoon-mvp/
├─ app.py
├─ requirements.txt
├─ data/
│  └─ demo_store.json
├─ templates/
│  ├─ base.html
│  ├─ index.html
│  ├─ demo.html
│  └─ store_preview.html
├─ static/
│  ├─ css/app.css
│  ├─ js/demo.js
│  ├─ js/store-preview.js
│  └─ favicon.svg
└─ tests/
   └─ test_app.py
```

## 주의

화면의 가게와 측정 수치는 모두 가상 데이터입니다. 한눈은 특정 AI 추천 순위나 노출을 보장하지 않으며, 사실에 기반한 정보 정비와 반복 측정을 지원하는 서비스입니다.
