# 한눈 랜딩 시안 — Professional / Museum 3D

`index.html`에서 두 버전을 전환합니다. HTML과 `assets` 폴더를 함께 보관하세요. 이전 시안은 수정하지 않았습니다.

## 01 전문 서비스형

1번의 흰 배경과 남색, 왼쪽 설명·오른쪽 결과 구성을 유지했습니다. Pretendard Variable 글꼴, 낮은 채도의 색, 얇은 선, 정돈된 수치와 표로 표현을 다듬었습니다. 리포트의 ChatGPT/Gemini 전환이 동작합니다.

## 02 뮤지엄 3D

같은 정보 구조에 Three.js로 직접 만든 건축 전시 모형을 넣었습니다. 미술관의 밝은 바닥, 낮은 전시대, 금속 프레임, 작은 가게에 집중하는 조명을 사용합니다. 좌우 회전·드래그·세 가지 전시 상태·움직임 정지가 동작합니다. 화면 밖에서는 렌더링을 쉬고, 동작 줄이기 설정을 따릅니다. WebGL이 없으면 설명을 표시합니다.

## 참고한 사이트

- [Linear](https://linear.app/): 서체 위계, 절제된 탐색 구조와 제품 화면 설명.
- [Stripe](https://stripe.com/): 가치 제안에서 구체적인 제품 결과로 이어지는 서비스 설명.
- [Getty — Sculpting Harmony](https://gehry.getty.edu/): 건축 모형을 다양한 각도에서 살펴보는 디지털 전시. [Getty의 3D 프로젝트 소개](https://www.getty.edu/projects/evolving-uses-of-3d-technologies/)도 확인.
- [Bourse de Commerce — Pinault Collection](https://www.pinaultcollection.com/en/boursedecommerce): 전시실의 밝은 재료, 공간과 작품의 비례, 절제된 안내.

원본 로고·사진·작품·3D 모델은 복제하지 않았습니다. 화면과 건축 모형은 한눈용으로 새로 제작했습니다. 미술관이 Three.js를 사용한다고 주장하는 문서는 아닙니다.

## 내용과 실행

- 최신 `01_기획/한눈_기획서.md` 기준: 3문항 × 10회 × 2모델, 계정당 무료 진단 1회. 실제 가입·측정·결제는 연결하지 않은 디자인 시안입니다.
- 가게·수치·질문·출처는 가상 예시입니다. 진단 시작 버튼은 입력 화면과 결과 예시를 시연합니다. 입력값은 저장·전송하지 않습니다.
- Three.js r180, Pretendard 1.3.9를 같은 폴더에 포함했습니다. CDN·외부 이미지·모델을 불러오지 않습니다. 각각의 라이선스는 `assets/*LICENSE.txt`입니다.
- 로컬 서버가 필요한 경우 이 폴더에서 `python -m http.server 8768 --bind 127.0.0.1` 실행 후 `http://127.0.0.1:8768`로 접속합니다.
